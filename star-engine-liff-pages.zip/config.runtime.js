window.__STAR_ENGINE_CONFIG__ = {
  API_BASE: 'https://chelov134999.app.n8n.cloud/webhook',
  CHATKIT_URL: 'https://liff.line.me/2008215846-5LwXlWVN',
  CHATKIT_CLIENT_SECRET:
    'ek_68f8ddca7db881908029bd97d51cb7190639d32c9a81805f_00eyJleHBpcmVzX2F0IjogMTc2MTE0MDc3MH0=',
  CHATKIT_GATEWAY_SECRET: '819ee92a9e3657b3c956efcadbeeb3e27a4e65b5c36788d3e35f007762b7996d',
  CHATKIT_APP_ID: '2008215846-5LwXlWVN',
  CHATKIT_REDIRECT_URL: 'https://test-star-engine.pages.dev/guardian-chat.html',
  CHATKIT_FALLBACK_URL: 'https://liff.line.me/STAR_ENGINE_INDEX',
  API_GATEWAY_BASE: 'https://chelov134999.app.n8n.cloud/webhook/ai',
  LIFF_ID: '2008215846-5LwXlWVN',
  REDUCED_MOTION: window.matchMedia('(prefers-reduced-motion: reduce)').matches
};
