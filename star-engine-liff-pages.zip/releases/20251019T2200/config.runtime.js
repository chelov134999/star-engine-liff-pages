window.__STAR_ENGINE_CONFIG__ = {
  API_BASE: 'https://chelov134999.app.n8n.cloud/webhook',
  CHATKIT_URL: 'https://chelov134999.github.io/star-engine-liff-pages/chatkit/',
  CHATKIT_TOKEN_ENDPOINT: 'https://chelov134999.app.n8n.cloud/webhook/chatkit/token',
  CHATKIT_WORKFLOW_ID: 'wf_68f8bec1169c81908cfe94e6c85e2a4a0f2cd7e47374bcc5',
  REDUCED_MOTION: window.matchMedia('(prefers-reduced-motion: reduce)').matches
};
