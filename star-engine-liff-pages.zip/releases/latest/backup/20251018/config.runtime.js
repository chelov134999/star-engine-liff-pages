window.__STAR_ENGINE_CONFIG__ = {
  API_BASE: 'https://chelov134999.app.n8n.cloud/webhook',
  CHATKIT_URL: 'https://liff.line.me/2008215846-5LwXlWVN?view=chatkit',
  REDUCED_MOTION: window.matchMedia('(prefers-reduced-motion: reduce)').matches
};
