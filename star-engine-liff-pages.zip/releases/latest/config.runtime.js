window.__STAR_ENGINE_CONFIG__ = {
  API_BASE: 'https://chelov134999.app.n8n.cloud/webhook',
  CHATKIT_URL: 'https://chelov134999.github.io/star-engine-liff-pages/chatkit/',
  CHATKIT_CLIENT_SECRET: '',
  CHATKIT_GATEWAY_SECRET: '',
  CHATKIT_APP_ID: '',
  CHATKIT_REDIRECT_URL: 'https://chelov134999.github.io/star-engine-liff-pages/guardian-chat.html',
  CHATKIT_FALLBACK_URL: 'https://chelov134999.github.io/star-engine-liff-pages/chatkit/',
  API_GATEWAY_BASE: 'https://chelov134999.app.n8n.cloud/webhook/ai',
  LIFF_ID: '2008215846-5LwXlWVN',
  REDUCED_MOTION: window.matchMedia('(prefers-reduced-motion: reduce)').matches
};
