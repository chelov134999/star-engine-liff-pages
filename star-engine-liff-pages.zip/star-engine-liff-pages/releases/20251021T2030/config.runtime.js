window.__STAR_ENGINE_CONFIG__ = {
  API_BASE: 'https://chelov134999.app.n8n.cloud/webhook',
  CHATKIT_URL: 'https://liff.line.me/2008215846-5LwXlWVN?view=chatkit',
  CHECKOUT_PRIMARY_URL: 'https://chelov134999.app.n8n.cloud/pay/star-guard-4980',
  CHECKOUT_SECONDARY_URL: 'https://chelov134999.app.n8n.cloud/pay/star-cabin-2980',
  PLANS_PAGE_URL: 'plans.html',
  SERP_DETAIL_URL: 'report-serp.html',
  REPORT_URL: 'report.html',
  FORM_URL: 'index.html',
  BUILD_TIMESTAMP: '20251021T2030',
  REDUCED_MOTION: window.matchMedia('(prefers-reduced-motion: reduce)').matches
};
